# Rest-assured
Includes complete source code of rest-assured java discussed in the youtube and udemy courses

## Course details
The complete rest-assured course is available in ExecuteAutomation YouTube channel here https://www.youtube.com/playlist?list=PL6tu16kXT9PpgqfMbMdzUzDenYgb0gbk0
