package pojo;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * AccountComplex
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-10-08T08:40:29.008+03:00[Asia/Riyadh]")

public class AccountComplex   {
  @JsonProperty("WalletId")
  private String walletId = null;

  @JsonProperty("Status")
  private String status = null;

  @JsonProperty("StatusUpdateDateTime")
  private OffsetDateTime statusUpdateDateTime = null;

  @JsonProperty("Currency")
  private String currency = null;

  @JsonProperty("AccountType")
  private String accountType = null;

  @JsonProperty("AccountSubType")
  private String accountSubType = null;

  @JsonProperty("Description")
  private String description = null;

  @JsonProperty("Nickname")
  private String nickname = null;

  @JsonProperty("Account")
  @Valid
  private List<AccountComplexAccount> account = null;

  public AccountComplex walletId(String walletId) {
    this.walletId = walletId;
    return this;
  }

  /**
   * A unique and immutable identifier used to identify the account resource. This identifier has no meaning to the account owner. This will be the primary account identifier.
   * @return walletId
  **/
  @ApiModelProperty(example = "er34sdo34olkpo54o3pk2k34po32k4k=", required = true, value = "A unique and immutable identifier used to identify the account resource. This identifier has no meaning to the account owner. This will be the primary account identifier.")
  @NotNull


  public String getWalletId() {
    return walletId;
  }

  public void setWalletId(String walletId) {
    this.walletId = walletId;
  }

  public AccountComplex status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Specifies the status of account resource in code form.
   * @return status
  **/
  @ApiModelProperty(example = "Enabled", value = "Specifies the status of account resource in code form.")


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public AccountComplex statusUpdateDateTime(OffsetDateTime statusUpdateDateTime) {
    this.statusUpdateDateTime = statusUpdateDateTime;
    return this;
  }

  /**
   * Date and time at which the resource status was updated.
   * @return statusUpdateDateTime
  **/
  @ApiModelProperty(value = "Date and time at which the resource status was updated.")

  @Valid

  public OffsetDateTime getStatusUpdateDateTime() {
    return statusUpdateDateTime;
  }

  public void setStatusUpdateDateTime(OffsetDateTime statusUpdateDateTime) {
    this.statusUpdateDateTime = statusUpdateDateTime;
  }

  public AccountComplex currency(String currency) {
    this.currency = currency;
    return this;
  }

  /**
   * Identification of the currency in which the account is held. Currency should only be used in case one and the same account number covers several currencies and the initiating party needs to identify which currency needs to be used for settlement on the account.
   * @return currency
  **/
  @ApiModelProperty(example = "SAR", required = true, value = "Identification of the currency in which the account is held. Currency should only be used in case one and the same account number covers several currencies and the initiating party needs to identify which currency needs to be used for settlement on the account.")
  @NotNull


  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public AccountComplex accountType(String accountType) {
    this.accountType = accountType;
    return this;
  }

  /**
   * Specifies the type of account (personal or business).
   * @return accountType
  **/
  @ApiModelProperty(example = "Personal", value = "Specifies the type of account (personal or business).")


  public String getAccountType() {
    return accountType;
  }

  public void setAccountType(String accountType) {
    this.accountType = accountType;
  }

  public AccountComplex accountSubType(String accountSubType) {
    this.accountSubType = accountSubType;
    return this;
  }

  /**
   * Specifies the sub type of account (product family group).
   * @return accountSubType
  **/
  @ApiModelProperty(example = "Savings", value = "Specifies the sub type of account (product family group).")


  public String getAccountSubType() {
    return accountSubType;
  }

  public void setAccountSubType(String accountSubType) {
    this.accountSubType = accountSubType;
  }

  public AccountComplex description(String description) {
    this.description = description;
    return this;
  }

  /**
   * Specifies the description of the account type.
   * @return description
  **/
  @ApiModelProperty(example = "Account is active for use.", value = "Specifies the description of the account type.")


  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public AccountComplex nickname(String nickname) {
    this.nickname = nickname;
    return this;
  }

  /**
   * The nickname of the wallet assigned by the wallet owner in order to provide an additional means of identification of the wallet.
   * @return nickname
  **/
  @ApiModelProperty(example = "Robert", value = "The nickname of the wallet assigned by the wallet owner in order to provide an additional means of identification of the wallet.")


  public String getNickname() {
    return nickname;
  }

  public void setNickname(String nickname) {
    this.nickname = nickname;
  }

  public AccountComplex account(List<AccountComplexAccount> account) {
    this.account = account;
    return this;
  }

  public AccountComplex addAccountItem(AccountComplexAccount accountItem) {
    if (this.account == null) {
      this.account = new ArrayList<AccountComplexAccount>();
    }
    this.account.add(accountItem);
    return this;
  }

  /**
   * Get account
   * @return account
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<AccountComplexAccount> getAccount() {
    return account;
  }

  public void setAccount(List<AccountComplexAccount> account) {
    this.account = account;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AccountComplex accountComplex = (AccountComplex) o;
    return Objects.equals(this.walletId, accountComplex.walletId) &&
        Objects.equals(this.status, accountComplex.status) &&
        Objects.equals(this.statusUpdateDateTime, accountComplex.statusUpdateDateTime) &&
        Objects.equals(this.currency, accountComplex.currency) &&
        Objects.equals(this.accountType, accountComplex.accountType) &&
        Objects.equals(this.accountSubType, accountComplex.accountSubType) &&
        Objects.equals(this.description, accountComplex.description) &&
        Objects.equals(this.nickname, accountComplex.nickname) &&
        Objects.equals(this.account, accountComplex.account);
  }

  @Override
  public int hashCode() {
    return Objects.hash(walletId, status, statusUpdateDateTime, currency, accountType, accountSubType, description, nickname, account);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AccountComplex {\n");
    
    sb.append("    walletId: ").append(toIndentedString(walletId)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    statusUpdateDateTime: ").append(toIndentedString(statusUpdateDateTime)).append("\n");
    sb.append("    currency: ").append(toIndentedString(currency)).append("\n");
    sb.append("    accountType: ").append(toIndentedString(accountType)).append("\n");
    sb.append("    accountSubType: ").append(toIndentedString(accountSubType)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    nickname: ").append(toIndentedString(nickname)).append("\n");
    sb.append("    account: ").append(toIndentedString(account)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

