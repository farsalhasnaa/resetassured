package pojo;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * AccountSimple
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-10-08T08:40:29.008+03:00[Asia/Riyadh]")

public class AccountSimple   {
  @JsonProperty("SchemeName")
  private String schemeName = null;

  @JsonProperty("Identification")
  private String identification = null;

  @JsonProperty("Name")
  private String name = null;

  @JsonProperty("SecondaryIdentification")
  private String secondaryIdentification = null;

  public AccountSimple schemeName(String schemeName) {
    this.schemeName = schemeName;
    return this;
  }

  /**
   * Name of the identification scheme, in a coded form as published in enumeration list. These schemes can be used to identify secondary account types linked to a wallet.
   * @return schemeName
  **/
  @ApiModelProperty(example = "KSA.SAIB.ACCOUNT", required = true, value = "Name of the identification scheme, in a coded form as published in enumeration list. These schemes can be used to identify secondary account types linked to a wallet.")
  @NotNull


  public String getSchemeName() {
    return schemeName;
  }

  public void setSchemeName(String schemeName) {
    this.schemeName = schemeName;
  }

  public AccountSimple identification(String identification) {
    this.identification = identification;
    return this;
  }

  /**
   * Identification assigned by an institution to identify an account. This identification is known by the account owner. This will be in line with the schemename above
   * @return identification
  **/
  @ApiModelProperty(example = "9855663125", required = true, value = "Identification assigned by an institution to identify an account. This identification is known by the account owner. This will be in line with the schemename above")
  @NotNull


  public String getIdentification() {
    return identification;
  }

  public void setIdentification(String identification) {
    this.identification = identification;
  }

  public AccountSimple name(String name) {
    this.name = name;
    return this;
  }

  /**
   * The account name is the name or names of the account owner(s) represented at an account level, as displayed by the ASPSP (API Provider/SAIB)'s online channels. Note, the account name is not the product name or the nickname of the account.
   * @return name
  **/
  @ApiModelProperty(example = "Riyaz khan", value = "The account name is the name or names of the account owner(s) represented at an account level, as displayed by the ASPSP (API Provider/SAIB)'s online channels. Note, the account name is not the product name or the nickname of the account.")


  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public AccountSimple secondaryIdentification(String secondaryIdentification) {
    this.secondaryIdentification = secondaryIdentification;
    return this;
  }

  /**
   * This is secondary identification of the account, as assigned by the account.
   * @return secondaryIdentification
  **/
  @ApiModelProperty(example = "9855663125", value = "This is secondary identification of the account, as assigned by the account.")


  public String getSecondaryIdentification() {
    return secondaryIdentification;
  }

  public void setSecondaryIdentification(String secondaryIdentification) {
    this.secondaryIdentification = secondaryIdentification;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AccountSimple accountSimple = (AccountSimple) o;
    return Objects.equals(this.schemeName, accountSimple.schemeName) &&
        Objects.equals(this.identification, accountSimple.identification) &&
        Objects.equals(this.name, accountSimple.name) &&
        Objects.equals(this.secondaryIdentification, accountSimple.secondaryIdentification);
  }

  @Override
  public int hashCode() {
    return Objects.hash(schemeName, identification, name, secondaryIdentification);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AccountSimple {\n");
    
    sb.append("    schemeName: ").append(toIndentedString(schemeName)).append("\n");
    sb.append("    identification: ").append(toIndentedString(identification)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    secondaryIdentification: ").append(toIndentedString(secondaryIdentification)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

