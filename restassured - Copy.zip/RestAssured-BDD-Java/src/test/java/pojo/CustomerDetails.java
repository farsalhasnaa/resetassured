package pojo;

import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * CustomerDetails
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-10-08T08:40:29.008+03:00[Asia/Riyadh]")

public class CustomerDetails   {
  @JsonProperty("NationalIdentityNumber")
  private Integer nationalIdentityNumber = null;

  @JsonProperty("KYC")
  private KYC KYC = null;

  @JsonProperty("CustomerId")
  private Integer customerId = null;

  public CustomerDetails nationalIdentityNumber(Integer nationalIdentityNumber) {
    this.nationalIdentityNumber = nationalIdentityNumber;
    return this;
  }

  /**
   * Saudi ID or Iqama Number
   * @return nationalIdentityNumber
  **/
  @ApiModelProperty(required = true, value = "Saudi ID or Iqama Number")
  @NotNull


  public Integer getNationalIdentityNumber() {
    return nationalIdentityNumber;
  }

  public void setNationalIdentityNumber(Integer nationalIdentityNumber) {
    this.nationalIdentityNumber = nationalIdentityNumber;
  }

  public CustomerDetails KYC(KYC KYC) {
    this.KYC = KYC;
    return this;
  }

  /**
   * Get KYC
   * @return KYC
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public KYC getKYC() {
    return KYC;
  }

  public void setKYC(KYC KYC) {
    this.KYC = KYC;
  }

  public CustomerDetails customerId(Integer customerId) {
    this.customerId = customerId;
    return this;
  }

  /**
   * Unique Customer Identification number
   * @return customerId
  **/
  @ApiModelProperty(example = "1122334455", required = true, value = "Unique Customer Identification number")
  @NotNull


  public Integer getCustomerId() {
    return customerId;
  }

  public void setCustomerId(Integer customerId) {
    this.customerId = customerId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CustomerDetails customerDetails = (CustomerDetails) o;
    return Objects.equals(this.nationalIdentityNumber, customerDetails.nationalIdentityNumber) &&
        Objects.equals(this.KYC, customerDetails.KYC) &&
        Objects.equals(this.customerId, customerDetails.customerId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(nationalIdentityNumber, KYC, customerId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CustomerDetails {\n");
    
    sb.append("    nationalIdentityNumber: ").append(toIndentedString(nationalIdentityNumber)).append("\n");
    sb.append("    KYC: ").append(toIndentedString(KYC)).append("\n");
    sb.append("    customerId: ").append(toIndentedString(customerId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

