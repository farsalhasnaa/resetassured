package pojo;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ChargeAmount
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-10-08T08:40:29.008+03:00[Asia/Riyadh]")

public class ChargeAmount   {
  @JsonProperty("Amount")
  private Double amount = null;

  @JsonProperty("Currency")
  private String currency = null;

  @JsonProperty("VAT")
  private Double VAT = null;

  public ChargeAmount amount(Double amount) {
    this.amount = amount;
    return this;
  }

  /**
   * Amount of charges applicable.
   * @return amount
  **/
  @ApiModelProperty(example = "10.0", required = true, value = "Amount of charges applicable.")
  @NotNull


  public Double getAmount() {
    return amount;
  }

  public void setAmount(Double amount) {
    this.amount = amount;
  }

  public ChargeAmount currency(String currency) {
    this.currency = currency;
    return this;
  }

  /**
   * Currency code. Always SAR.
   * @return currency
  **/
  @ApiModelProperty(example = "SAR", required = true, value = "Currency code. Always SAR.")
  @NotNull


  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public ChargeAmount VAT(Double VAT) {
    this.VAT = VAT;
    return this;
  }

  /**
   * VAT amount if applicable in SAR.
   * @return VAT
  **/
  @ApiModelProperty(example = "0.0", value = "VAT amount if applicable in SAR.")


  public Double getVAT() {
    return VAT;
  }

  public void setVAT(Double VAT) {
    this.VAT = VAT;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChargeAmount chargeAmount = (ChargeAmount) o;
    return Objects.equals(this.amount, chargeAmount.amount) &&
        Objects.equals(this.currency, chargeAmount.currency) &&
        Objects.equals(this.VAT, chargeAmount.VAT);
  }

  @Override
  public int hashCode() {
    return Objects.hash(amount, currency, VAT);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ChargeAmount {\n");
    
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    currency: ").append(toIndentedString(currency)).append("\n");
    sb.append("    VAT: ").append(toIndentedString(VAT)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

