package pojo;

import java.time.LocalDate;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * OnboardRequest
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-10-08T08:40:29.008+03:00[Asia/Riyadh]")

public class OnboardRequest   {
  @JsonProperty("DateOfBirth")
  private LocalDate dateOfBirth = null;

  @JsonProperty("MobilePhoneNumber")
  private Integer mobilePhoneNumber = null;

  @JsonProperty("NationalIdentityNumber")
  private Integer nationalIdentityNumber = null;

  @JsonProperty("CustomerType")
  private String customerType = null;

  @JsonProperty("DeviceId")
  private Integer deviceId = null;

  @JsonProperty("InitialBalance")
  private Double initialBalance = null;

  @JsonProperty("IDType")
  private String idType = null;

  public OnboardRequest dateOfBirth(LocalDate dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
    return this;
  }

  /**
   * Hijra for Saudi Citizen and Georgian for expat.
   * @return dateOfBirth
  **/
  @ApiModelProperty(required = true, value = "Hijra for Saudi Citizen and Georgian for expat.")
  @NotNull

  @Valid

  public LocalDate getDateOfBirth() {
    return dateOfBirth;
  }

  public void setDateOfBirth(LocalDate dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
  }

  public OnboardRequest mobilePhoneNumber(Integer mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
    return this;
  }

  /**
   * Saudi Mobile number
   * @return mobilePhoneNumber
  **/
  @ApiModelProperty(required = true, value = "Saudi Mobile number")
  @NotNull


  public Integer getMobilePhoneNumber() {
    return mobilePhoneNumber;
  }

  public void setMobilePhoneNumber(Integer mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
  }

  public OnboardRequest nationalIdentityNumber(Integer nationalIdentityNumber) {
    this.nationalIdentityNumber = nationalIdentityNumber;
    return this;
  }

  /**
   * Saudi ID or Iqama Number
   * @return nationalIdentityNumber
  **/
  @ApiModelProperty(required = true, value = "Saudi ID or Iqama Number")
  @NotNull


  public Integer getNationalIdentityNumber() {
    return nationalIdentityNumber;
  }

  public void setNationalIdentityNumber(Integer nationalIdentityNumber) {
    this.nationalIdentityNumber = nationalIdentityNumber;
  }

  public OnboardRequest customerType(String customerType) {
    this.customerType = customerType;
    return this;
  }

  /**
   * Type of Customer
   * @return customerType
  **/
  @ApiModelProperty(example = "Captain/Merchant/Customer", required = true, value = "Type of Customer")
  @NotNull


  public String getCustomerType() {
    return customerType;
  }

  public void setCustomerType(String customerType) {
    this.customerType = customerType;
  }

  public OnboardRequest deviceId(Integer deviceId) {
    this.deviceId = deviceId;
    return this;
  }

  /**
   * UUID of the customer device
   * @return deviceId
  **/
  @ApiModelProperty(example = "123154", value = "UUID of the customer device")


  public Integer getDeviceId() {
    return deviceId;
  }

  public void setDeviceId(Integer deviceId) {
    this.deviceId = deviceId;
  }

  public OnboardRequest initialBalance(Double initialBalance) {
    this.initialBalance = initialBalance;
    return this;
  }

  /**
   * Initial amount to deposit it into the account and will always be in SAR
   * @return initialBalance
  **/
  @ApiModelProperty(example = "500.33", value = "Initial amount to deposit it into the account and will always be in SAR")


  public Double getInitialBalance() {
    return initialBalance;
  }

  public void setInitialBalance(Double initialBalance) {
    this.initialBalance = initialBalance;
  }

  public OnboardRequest idType(String idType) {
    this.idType = idType;
    return this;
  }

  /**
   * Type of ID
   * @return idType
  **/
  @ApiModelProperty(example = "NationalID", required = true, value = "Type of ID")
  @NotNull


  public String getIdType() {
    return idType;
  }

  public void setIdType(String idType) {
    this.idType = idType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OnboardRequest onboardRequest = (OnboardRequest) o;
    return Objects.equals(this.dateOfBirth, onboardRequest.dateOfBirth) &&
        Objects.equals(this.mobilePhoneNumber, onboardRequest.mobilePhoneNumber) &&
        Objects.equals(this.nationalIdentityNumber, onboardRequest.nationalIdentityNumber) &&
        Objects.equals(this.customerType, onboardRequest.customerType) &&
        Objects.equals(this.deviceId, onboardRequest.deviceId) &&
        Objects.equals(this.initialBalance, onboardRequest.initialBalance) &&
        Objects.equals(this.idType, onboardRequest.idType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(dateOfBirth, mobilePhoneNumber, nationalIdentityNumber, customerType, deviceId, initialBalance, idType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OnboardRequest {\n");
    
    sb.append("    dateOfBirth: ").append(toIndentedString(dateOfBirth)).append("\n");
    sb.append("    mobilePhoneNumber: ").append(toIndentedString(mobilePhoneNumber)).append("\n");
    sb.append("    nationalIdentityNumber: ").append(toIndentedString(nationalIdentityNumber)).append("\n");
    sb.append("    customerType: ").append(toIndentedString(customerType)).append("\n");
    sb.append("    deviceId: ").append(toIndentedString(deviceId)).append("\n");
    sb.append("    initialBalance: ").append(toIndentedString(initialBalance)).append("\n");
    sb.append("    idType: ").append(toIndentedString(idType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

