package pojo;

public class TokenTPPObj {
	
	String token_type;
	String access_token;
	String expires_in;
	String consented_on;
	String scope;
	/**
	 * @return the token_type
	 */
	public String getToken_type() {
		return token_type;
	}
	/**
	 * @param token_type the token_type to set
	 */
	public void setToken_type(String token_type) {
		this.token_type = token_type;
	}
	/**
	 * @return the access_token
	 */
	public String getAccess_token() {
		return access_token;
	}
	/**
	 * @param access_token the access_token to set
	 */
	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}
	/**
	 * @return the expires_in
	 */
	public String getExpires_in() {
		return expires_in;
	}
	/**
	 * @param expires_in the expires_in to set
	 */
	public void setExpires_in(String expires_in) {
		this.expires_in = expires_in;
	}
	/**
	 * @return the consented_on
	 */
	public String getConsented_on() {
		return consented_on;
	}
	/**
	 * @param consented_on the consented_on to set
	 */
	public void setConsented_on(String consented_on) {
		this.consented_on = consented_on;
	}
	/**
	 * @return the scope
	 */
	public String getScope() {
		return scope;
	}
	/**
	 * @param scope the scope to set
	 */
	public void setScope(String scope) {
		this.scope = scope;
	}
	@Override
	public String toString() {
		return "TokenTPPObj [token_type=" + token_type + ", access_token=" + access_token + ", expires_in=" + expires_in
				+ ", consented_on=" + consented_on + ", scope=" + scope + "]";
	}
	
	
	
}
