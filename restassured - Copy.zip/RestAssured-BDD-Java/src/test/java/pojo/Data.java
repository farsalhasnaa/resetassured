package pojo;

import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 */
@ApiModel(description = "")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-10-08T08:40:29.008+03:00[Asia/Riyadh]")

public class Data   {
  @JsonProperty("CaseId")
  private String caseId = null;

  @JsonProperty("CustomerDetails")
  private CustomerDetails customerDetails = null;

  @JsonProperty("Account")
  private AccountComplex account = null;

  @JsonProperty("Consent")
  private Consent consent = null;

  @JsonProperty("WalletCreditDetails")
  private WalletCreditDetails walletCreditDetails = null;

  public Data caseId(String caseId) {
    this.caseId = caseId;
    return this;
  }

  /**
   * Id that is assigned by ASPSP for each on boarding case.
   * @return caseId
  **/
  @ApiModelProperty(example = "CARM-135435-SAIB", required = true, value = "Id that is assigned by ASPSP for each on boarding case.")
  @NotNull


  public String getCaseId() {
    return caseId;
  }

  public void setCaseId(String caseId) {
    this.caseId = caseId;
  }

  public Data customerDetails(CustomerDetails customerDetails) {
    this.customerDetails = customerDetails;
    return this;
  }

  /**
   * Get customerDetails
   * @return customerDetails
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public CustomerDetails getCustomerDetails() {
    return customerDetails;
  }

  public void setCustomerDetails(CustomerDetails customerDetails) {
    this.customerDetails = customerDetails;
  }

  public Data account(AccountComplex account) {
    this.account = account;
    return this;
  }

  /**
   * Get account
   * @return account
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public AccountComplex getAccount() {
    return account;
  }

  public void setAccount(AccountComplex account) {
    this.account = account;
  }

  public Data consent(Consent consent) {
    this.consent = consent;
    return this;
  }

  /**
   * Get consent
   * @return consent
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public Consent getConsent() {
    return consent;
  }

  public void setConsent(Consent consent) {
    this.consent = consent;
  }

  public Data walletCreditDetails(WalletCreditDetails walletCreditDetails) {
    this.walletCreditDetails = walletCreditDetails;
    return this;
  }

  /**
   * Get walletCreditDetails
   * @return walletCreditDetails
  **/
  @ApiModelProperty(value = "")

  @Valid

  public WalletCreditDetails getWalletCreditDetails() {
    return walletCreditDetails;
  }

  public void setWalletCreditDetails(WalletCreditDetails walletCreditDetails) {
    this.walletCreditDetails = walletCreditDetails;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Data data = (Data) o;
    return Objects.equals(this.caseId, data.caseId) &&
        Objects.equals(this.customerDetails, data.customerDetails) &&
        Objects.equals(this.account, data.account) &&
        Objects.equals(this.consent, data.consent) &&
        Objects.equals(this.walletCreditDetails, data.walletCreditDetails);
  }

  @Override
  public int hashCode() {
    return Objects.hash(caseId, customerDetails, account, consent, walletCreditDetails);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Data {\n");
    
    sb.append("    caseId: ").append(toIndentedString(caseId)).append("\n");
    sb.append("    customerDetails: ").append(toIndentedString(customerDetails)).append("\n");
    sb.append("    account: ").append(toIndentedString(account)).append("\n");
    sb.append("    consent: ").append(toIndentedString(consent)).append("\n");
    sb.append("    walletCreditDetails: ").append(toIndentedString(walletCreditDetails)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

