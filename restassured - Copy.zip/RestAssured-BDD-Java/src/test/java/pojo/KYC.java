package pojo;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * KYC
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-10-08T08:40:29.008+03:00[Asia/Riyadh]")

public class KYC   {
  @JsonProperty("Level")
  private String level = null;

  @JsonProperty("Status")
  private String status = null;

  public KYC level(String level) {
    this.level = level;
    return this;
  }

  /**
   * Level of KYC
   * @return level
  **/
  @ApiModelProperty(example = "Lite/Full", required = true, value = "Level of KYC")
  @NotNull


  public String getLevel() {
    return level;
  }

  public void setLevel(String level) {
    this.level = level;
  }

  public KYC status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Status of KYC check
   * @return status
  **/
  @ApiModelProperty(example = "Success/Pending/Failed", required = true, value = "Status of KYC check")
  @NotNull


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    KYC KYC = (KYC) o;
    return Objects.equals(this.level, KYC.level) &&
        Objects.equals(this.status, KYC.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(level, status);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class KYC {\n");
    
    sb.append("    level: ").append(toIndentedString(level)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

