package pojo;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * AccountComplexAccount
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-10-08T08:40:29.008+03:00[Asia/Riyadh]")

public class AccountComplexAccount   {
  @JsonProperty("Servicer")
  private Servicer servicer = null;

  @JsonProperty("SecondaryIdentification")
  private String secondaryIdentification = null;

  @JsonProperty("SchemeName")
  private String schemeName = null;

  @JsonProperty("Identification")
  private String identification = null;

  @JsonProperty("Name")
  private String name = null;

  public AccountComplexAccount servicer(Servicer servicer) {
    this.servicer = servicer;
    return this;
  }

  /**
   * Get servicer
   * @return servicer
  **/
  @ApiModelProperty(value = "")

  @Valid

  public Servicer getServicer() {
    return servicer;
  }

  public void setServicer(Servicer servicer) {
    this.servicer = servicer;
  }

  public AccountComplexAccount secondaryIdentification(String secondaryIdentification) {
    this.secondaryIdentification = secondaryIdentification;
    return this;
  }

  /**
   * This is secondary identification of the account, as assigned by the account.
   * @return secondaryIdentification
  **/
  @ApiModelProperty(example = "9855663125", value = "This is secondary identification of the account, as assigned by the account.")


  public String getSecondaryIdentification() {
    return secondaryIdentification;
  }

  public void setSecondaryIdentification(String secondaryIdentification) {
    this.secondaryIdentification = secondaryIdentification;
  }

  public AccountComplexAccount schemeName(String schemeName) {
    this.schemeName = schemeName;
    return this;
  }

  /**
   * Name of the identification scheme, in a coded form as published in enumeration list. These schemes can be used to identify secondary account types linked to a wallet.
   * @return schemeName
  **/
  @ApiModelProperty(example = "KSA.SAIB.ACCOUNT", value = "Name of the identification scheme, in a coded form as published in enumeration list. These schemes can be used to identify secondary account types linked to a wallet.")


  public String getSchemeName() {
    return schemeName;
  }

  public void setSchemeName(String schemeName) {
    this.schemeName = schemeName;
  }

  public AccountComplexAccount identification(String identification) {
    this.identification = identification;
    return this;
  }

  /**
   * Identification assigned by an institution to identify an account. This identification is known by the account owner. This will be in line with the schemename above
   * @return identification
  **/
  @ApiModelProperty(example = "9855663125", value = "Identification assigned by an institution to identify an account. This identification is known by the account owner. This will be in line with the schemename above")


  public String getIdentification() {
    return identification;
  }

  public void setIdentification(String identification) {
    this.identification = identification;
  }

  public AccountComplexAccount name(String name) {
    this.name = name;
    return this;
  }

  /**
   * The account name is the name or names of the account owner(s) represented at an account level, as displayed by the ASPSP (API Provider/SAIB)'s online channels. Note, the account name is not the product name or the nickname of the account.
   * @return name
  **/
  @ApiModelProperty(example = "Riyaz khan", value = "The account name is the name or names of the account owner(s) represented at an account level, as displayed by the ASPSP (API Provider/SAIB)'s online channels. Note, the account name is not the product name or the nickname of the account.")


  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AccountComplexAccount accountComplexAccount = (AccountComplexAccount) o;
    return Objects.equals(this.servicer, accountComplexAccount.servicer) &&
        Objects.equals(this.secondaryIdentification, accountComplexAccount.secondaryIdentification) &&
        Objects.equals(this.schemeName, accountComplexAccount.schemeName) &&
        Objects.equals(this.identification, accountComplexAccount.identification) &&
        Objects.equals(this.name, accountComplexAccount.name);
  }

  @Override
  public int hashCode() {
    return Objects.hash(servicer, secondaryIdentification, schemeName, identification, name);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AccountComplexAccount {\n");
    
    sb.append("    servicer: ").append(toIndentedString(servicer)).append("\n");
    sb.append("    secondaryIdentification: ").append(toIndentedString(secondaryIdentification)).append("\n");
    sb.append("    schemeName: ").append(toIndentedString(schemeName)).append("\n");
    sb.append("    identification: ").append(toIndentedString(identification)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

