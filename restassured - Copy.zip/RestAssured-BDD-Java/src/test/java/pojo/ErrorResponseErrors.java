package pojo;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ErrorResponseErrors
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-10-08T08:40:29.008+03:00[Asia/Riyadh]")

public class ErrorResponseErrors   {
  @JsonProperty("Path")
  private String path = null;

  @JsonProperty("Message")
  private String message = null;

  @JsonProperty("ErrorCode")
  private String errorCode = null;

  @JsonProperty("Url")
  private String url = null;

  public ErrorResponseErrors path(String path) {
    this.path = path;
    return this;
  }

  /**
   * Recommended but optional reference to the JSON Path of the field with error.
   * @return path
  **/
  @ApiModelProperty(example = "Data.Initiation.InstructedAmount.Currency", value = "Recommended but optional reference to the JSON Path of the field with error.")


  public String getPath() {
    return path;
  }

  public void setPath(String path) {
    this.path = path;
  }

  public ErrorResponseErrors message(String message) {
    this.message = message;
    return this;
  }

  /**
   * A description of the error that occurred
   * @return message
  **/
  @ApiModelProperty(example = "A mandatory field isn't supplied or RequestedExecutionDateTime must be in future", value = "A description of the error that occurred")


  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public ErrorResponseErrors errorCode(String errorCode) {
    this.errorCode = errorCode;
    return this;
  }

  /**
   * Low level textual error code
   * @return errorCode
  **/
  @ApiModelProperty(example = "UK.OBIE.Field.Missing", value = "Low level textual error code")


  public String getErrorCode() {
    return errorCode;
  }

  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  public ErrorResponseErrors url(String url) {
    this.url = url;
    return this;
  }

  /**
   * URL to help remediate the problem, or provide more information, or to API Reference, or help etc.
   * @return url
  **/
  @ApiModelProperty(example = "www.developer.saib.com", value = "URL to help remediate the problem, or provide more information, or to API Reference, or help etc.")


  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ErrorResponseErrors errorResponseErrors = (ErrorResponseErrors) o;
    return Objects.equals(this.path, errorResponseErrors.path) &&
        Objects.equals(this.message, errorResponseErrors.message) &&
        Objects.equals(this.errorCode, errorResponseErrors.errorCode) &&
        Objects.equals(this.url, errorResponseErrors.url);
  }

  @Override
  public int hashCode() {
    return Objects.hash(path, message, errorCode, url);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ErrorResponseErrors {\n");
    
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    errorCode: ").append(toIndentedString(errorCode)).append("\n");
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

