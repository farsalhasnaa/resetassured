package pojo;

import java.time.OffsetDateTime;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * WalletCreditDetails
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-10-08T08:40:29.008+03:00[Asia/Riyadh]")

public class WalletCreditDetails   {
  @JsonProperty("WalletId")
  private String walletId = null;

  @JsonProperty("Amount")
  private Double amount = null;

  @JsonProperty("Currency")
  private String currency = null;

  @JsonProperty("CreationDateTime")
  private OffsetDateTime creationDateTime = null;

  @JsonProperty("Status")
  private String status = null;

  @JsonProperty("Debtor")
  private AccountSimple debtor = null;

  @JsonProperty("TransactionId")
  private String transactionId = null;

  @JsonProperty("ChargeAmount")
  private ChargeAmount chargeAmount = null;

  public WalletCreditDetails walletId(String walletId) {
    this.walletId = walletId;
    return this;
  }

  /**
   * Wallet ID of the customer which is the destination in case of credit.
   * @return walletId
  **/
  @ApiModelProperty(example = "er34sdo34olkpo54o3pk2k34po32k4k=", required = true, value = "Wallet ID of the customer which is the destination in case of credit.")
  @NotNull


  public String getWalletId() {
    return walletId;
  }

  public void setWalletId(String walletId) {
    this.walletId = walletId;
  }

  public WalletCreditDetails amount(Double amount) {
    this.amount = amount;
    return this;
  }

  /**
   * Total amount credited to source. This will be the latest balance amount.
   * @return amount
  **/
  @ApiModelProperty(example = "500.0", required = true, value = "Total amount credited to source. This will be the latest balance amount.")
  @NotNull


  public Double getAmount() {
    return amount;
  }

  public void setAmount(Double amount) {
    this.amount = amount;
  }

  public WalletCreditDetails currency(String currency) {
    this.currency = currency;
    return this;
  }

  /**
   * Currency code of debited amount. Always SAR.
   * @return currency
  **/
  @ApiModelProperty(example = "SAR", required = true, value = "Currency code of debited amount. Always SAR.")
  @NotNull


  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public WalletCreditDetails creationDateTime(OffsetDateTime creationDateTime) {
    this.creationDateTime = creationDateTime;
    return this;
  }

  /**
   * Date time when the credit was created.
   * @return creationDateTime
  **/
  @ApiModelProperty(required = true, value = "Date time when the credit was created.")
  @NotNull

  @Valid

  public OffsetDateTime getCreationDateTime() {
    return creationDateTime;
  }

  public void setCreationDateTime(OffsetDateTime creationDateTime) {
    this.creationDateTime = creationDateTime;
  }

  public WalletCreditDetails status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Status of the transaction
   * @return status
  **/
  @ApiModelProperty(example = "Pending", required = true, value = "Status of the transaction")
  @NotNull


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public WalletCreditDetails debtor(AccountSimple debtor) {
    this.debtor = debtor;
    return this;
  }

  /**
   * Get debtor
   * @return debtor
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public AccountSimple getDebtor() {
    return debtor;
  }

  public void setDebtor(AccountSimple debtor) {
    this.debtor = debtor;
  }

  public WalletCreditDetails transactionId(String transactionId) {
    this.transactionId = transactionId;
    return this;
  }

  /**
   * Transaction identification for the credit operation
   * @return transactionId
  **/
  @ApiModelProperty(example = "5465454654", required = true, value = "Transaction identification for the credit operation")
  @NotNull


  public String getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public WalletCreditDetails chargeAmount(ChargeAmount chargeAmount) {
    this.chargeAmount = chargeAmount;
    return this;
  }

  /**
   * Get chargeAmount
   * @return chargeAmount
  **/
  @ApiModelProperty(value = "")

  @Valid

  public ChargeAmount getChargeAmount() {
    return chargeAmount;
  }

  public void setChargeAmount(ChargeAmount chargeAmount) {
    this.chargeAmount = chargeAmount;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    WalletCreditDetails walletCreditDetails = (WalletCreditDetails) o;
    return Objects.equals(this.walletId, walletCreditDetails.walletId) &&
        Objects.equals(this.amount, walletCreditDetails.amount) &&
        Objects.equals(this.currency, walletCreditDetails.currency) &&
        Objects.equals(this.creationDateTime, walletCreditDetails.creationDateTime) &&
        Objects.equals(this.status, walletCreditDetails.status) &&
        Objects.equals(this.debtor, walletCreditDetails.debtor) &&
        Objects.equals(this.transactionId, walletCreditDetails.transactionId) &&
        Objects.equals(this.chargeAmount, walletCreditDetails.chargeAmount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(walletId, amount, currency, creationDateTime, status, debtor, transactionId, chargeAmount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class WalletCreditDetails {\n");
    
    sb.append("    walletId: ").append(toIndentedString(walletId)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    currency: ").append(toIndentedString(currency)).append("\n");
    sb.append("    creationDateTime: ").append(toIndentedString(creationDateTime)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    debtor: ").append(toIndentedString(debtor)).append("\n");
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    chargeAmount: ").append(toIndentedString(chargeAmount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

