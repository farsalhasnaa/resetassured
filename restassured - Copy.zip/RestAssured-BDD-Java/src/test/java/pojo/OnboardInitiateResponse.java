package pojo;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * OnboardInitiateResponse
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-10-08T08:40:29.008+03:00[Asia/Riyadh]")

public class OnboardInitiateResponse   {
  @JsonProperty("CaseId")
  private String caseId = null;

  @JsonProperty("Description")
  private String description = null;

  @JsonProperty("Status")
  private String status = null;

  @JsonProperty("OTPFlag")
  private String otPFlag = null;

  public OnboardInitiateResponse caseId(String caseId) {
    this.caseId = caseId;
    return this;
  }

  /**
   * Id that is assigned by ASPSP for each on boarding case
   * @return caseId
  **/
  @ApiModelProperty(example = "SAIB1234DW", required = true, value = "Id that is assigned by ASPSP for each on boarding case")
  @NotNull


  public String getCaseId() {
    return caseId;
  }

  public void setCaseId(String caseId) {
    this.caseId = caseId;
  }

  public OnboardInitiateResponse description(String description) {
    this.description = description;
    return this;
  }

  /**
   * Description of the operation
   * @return description
  **/
  @ApiModelProperty(example = "Waiting for OTP", required = true, value = "Description of the operation")
  @NotNull


  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public OnboardInitiateResponse status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Status of on boarding
   * @return status
  **/
  @ApiModelProperty(example = "Pending/Failed", required = true, value = "Status of on boarding")
  @NotNull


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public OnboardInitiateResponse otPFlag(String otPFlag) {
    this.otPFlag = otPFlag;
    return this;
  }

  /**
   * The source from where OTP was sent to Customer
   * @return otPFlag
  **/
  @ApiModelProperty(example = "SAIB", required = true, value = "The source from where OTP was sent to Customer")
  @NotNull


  public String getOtPFlag() {
    return otPFlag;
  }

  public void setOtPFlag(String otPFlag) {
    this.otPFlag = otPFlag;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OnboardInitiateResponse onboardInitiateResponse = (OnboardInitiateResponse) o;
    return Objects.equals(this.caseId, onboardInitiateResponse.caseId) &&
        Objects.equals(this.description, onboardInitiateResponse.description) &&
        Objects.equals(this.status, onboardInitiateResponse.status) &&
        Objects.equals(this.otPFlag, onboardInitiateResponse.otPFlag);
  }

  @Override
  public int hashCode() {
    return Objects.hash(caseId, description, status, otPFlag);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OnboardInitiateResponse {\n");
    
    sb.append("    caseId: ").append(toIndentedString(caseId)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    otPFlag: ").append(toIndentedString(otPFlag)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

