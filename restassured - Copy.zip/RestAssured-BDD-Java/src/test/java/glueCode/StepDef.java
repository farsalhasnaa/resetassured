package glueCode;


import java.util.HashMap;

import cucumber.api.java.en.Given;
import gherkin.deps.com.google.gson.Gson;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import pojo.TokenTPPObj;
import utilities.RestAssuredExtension;


public class StepDef extends RestAssuredExtension {
	public static ResponseOptions<Response> response;
	TokenTPPObj tokenTPPObj;
   
    @Given("^app wants to be authrized with body$")
    public void app_wants_to_be_authrized_with_body() throws Throwable {
    	 //Set body
    	System.out.println(tokenTPPObj);
        HashMap<String, String> body = new HashMap<String, String>();
        body.put("grant_type", "client_credentials");
        body.put("scope", "openid");
        body.put("client_id", "5e825038329d381f6f7a05f37f3f1719");
        body.put("client_secret", "8c2b417584ddb66582a3d83194b380ee");
        //Perform post operation
        	response = RestAssuredExtension.PostOpsWithBody("/saib-it/sandbox/oidc/tpp/oauth2/token", body);
        	Gson gson = new Gson(); 
            tokenTPPObj = gson.fromJson(response.body().asString(), TokenTPPObj.class);
            System.out.println(tokenTPPObj.getAccess_token());
    }

   
}